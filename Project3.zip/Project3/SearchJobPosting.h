
#include <iostream>
#include <string>
#include <string.h>
#include <cstdio>

using namespace std;

class SearchJobPosting
{
public:
    void showResult();
};