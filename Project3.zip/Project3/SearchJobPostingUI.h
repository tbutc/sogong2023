
#include <iostream>
#include <string>
#include <string.h>
#include <cstdio>

using namespace std;

class SearchJobPostingUI
{
public:
    void startinterface();
    void searchJobPosting();
};