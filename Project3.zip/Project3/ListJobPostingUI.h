﻿#include "ListJobPosting.h"
#include <iostream>

using namespace std;

class ListJobPostingUI {
private:


public:
    ListJobPostingUI();
    void startinterface(vector<JobDetail> details);
};
