#pragma
#include <iostream>
#include <string>
#include <string.h>
#include <cstdio>

using namespace std;

class memWithdrawUI
{
public:
    void startInterface();
    void memberWithdraw();
};