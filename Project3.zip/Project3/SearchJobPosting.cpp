#include <iostream>
#include <string>
#include <cstdio>

#include "SearchJobPosting.h"

void SearchJobPosting::showResult() {
	//~User();
}