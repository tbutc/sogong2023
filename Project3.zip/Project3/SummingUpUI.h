#include <iostream>
#include "SummingUp.h"
using namespace std;

class SummingUpUI {
private:

public:
    SummingUpUI();
    void startinterface(string name, int usertype, vector<Application> Applications);
};
