#include <iostream>
#include <string>
#include <cstdio>

#include "memWithdraw.h"

void memWithdraw::showResult() {
	//~User();
}