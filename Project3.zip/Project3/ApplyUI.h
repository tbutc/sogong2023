#include "Apply.h"

class ApplyUI
{
private:

public:
    void showInterface();

    void ApplyRequest();
};
