#include <string>
#include "Application.h"

using namespace std;

class ApplicationStatus {
public:


    void deleteOperation();

    void cancelApplication();
};