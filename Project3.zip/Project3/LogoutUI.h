#pragma
#include "User.h"

class LogoutUI {

private:

public:
    void startInterface();
    User * LogoutRequest(vector <User>* user_list, User* logout_user);
};