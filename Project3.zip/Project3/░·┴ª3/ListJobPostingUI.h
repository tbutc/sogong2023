#include "ListJobPosting.h"
#include <iostream>

using namespace std;

class ListJobPostingUI {
private:


public:
    ListJobPostingUI();
    void startinterface(string* const cn, vector<JobPosting> jobPostings);
};
