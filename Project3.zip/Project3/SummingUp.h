#include <string>
#include <vector>
#include <map>
#include "JobPosting.h"


class SummingUp {
private:

public:
	SummingUp();
	map<string, int> sumup(string name, int usertype, vector<Aplication> Aplications);
};
