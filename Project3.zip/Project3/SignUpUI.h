#pragma
#include "User.h"

class SignUpUI // ȸ������ boundary
{
private:

public:
    void startInterface();

    User signup(ifstream& inputFile);
};